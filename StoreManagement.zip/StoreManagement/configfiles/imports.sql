insert into CITY values(1,'Florida',32004);
insert into CITY values(0,'NewYork',10001);